import { Component, OnInit } from '@angular/core';
import { User } from '../User';
import { UserService } from '../user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private user:UserService) { }
us:User=new User();

  ngOnInit(): void {
  }
  saveuser(obj:any){
    this.us.firstname=obj.firstname;
    this.us.lastname=obj.lastname;
    this.us.email=obj.email;
    this.us.pass=obj.pass;
    this.us.cpass=obj.cpass;
    this.us.mobile=obj.mobile;
    if(this.us !==null){
    this.user.save(this.us).subscribe((res)=>{
    console.log(res);
    })
    
    }

  }
}
