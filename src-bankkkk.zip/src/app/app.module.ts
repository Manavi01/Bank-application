import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { LoanComponent } from './loan/loan.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { ServiceComponent } from './service/service.component';
import { NavbarComponent } from './navbar/navbar.component';
import { FooterComponent } from './footer/footer.component';
import { User1Component } from './user1/user1.component';
import { User2Component } from './user2/user2.component';
import { CarloanComponent } from './carloan/carloan.component';
import { GoldloanComponent } from './goldloan/goldloan.component';
import { EducationloanComponent } from './educationloan/educationloan.component';
import{HttpClient, HttpClientModule} from '@angular/common/http';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    LoanComponent,
    AboutComponent,
    ContactComponent,
    ServiceComponent,
    NavbarComponent,
    FooterComponent,
    User1Component,
    User2Component,
    CarloanComponent,
    GoldloanComponent,
    EducationloanComponent,
 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
