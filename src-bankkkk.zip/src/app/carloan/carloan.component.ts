import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carloan',
  templateUrl: './carloan.component.html',
  styleUrls: ['./carloan.component.css']
})
export class CarloanComponent implements OnInit {
  amount:number=0;
  constructor() { }

  ngOnInit(): void {
  }
  demo(val1:number,val2:number){

    this.amount=(val1*val2*0.04)/100;
    }

}
