import { Component, DoCheck, OnInit } from '@angular/core';
import { DataService } from '../data.service';



@Component({
selector: 'person1',
templateUrl: './person1.component.html',
styleUrls: ['./person1.component.css']
})
export class Person1Component implements OnInit,DoCheck{
msg:any=[];

constructor(private data1:DataService) {



}

ngOnInit(): void {
}
ngDoCheck(): void {
this.msg=this.data1.callData();
}





send(msg:any)
{
this.msg=this.data1.dataServe("Manavi:"+msg)
this.msg=`Manavi:${msg}`;
}



}