import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { CarloanComponent } from './carloan/carloan.component';
import { ContactComponent } from './contact/contact.component';
import { EducationloanComponent } from './educationloan/educationloan.component';
import { GoldloanComponent } from './goldloan/goldloan.component';
import { HomeComponent } from './home/home.component';
import { LoanComponent } from './loan/loan.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ServiceComponent } from './service/service.component';

const routes: Routes = [
  { path:'', component:HomeComponent},
  { path:'about', component:AboutComponent},
  { path:'contact', component:ContactComponent},
  { path:'loan', component:LoanComponent},
  { path:'service', component:ServiceComponent},
  { path:'login', component:LoginComponent},
  { path:'carloan', component:CarloanComponent},
  { path:'goldloan', component:GoldloanComponent},
  { path:'educationloan', component:EducationloanComponent},
  
  { path:'register', component:RegisterComponent}
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
