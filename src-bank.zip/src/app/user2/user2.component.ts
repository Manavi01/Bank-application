import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-user2',
  templateUrl: './user2.component.html',
  styleUrls: ['./user2.component.css']
})
export class User2Component implements OnInit {

  msg:any=[];
constructor(private dataService:DataService) { }



ngOnInit(): void {
}
ngDoCheck(): void {
this.msg=this.dataService.callData();
}
send(msg:any)
{
this.msg=this.dataService.getData("admin:"+msg);
}
}
