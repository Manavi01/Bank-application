export class User{
    firstname:string='';
    lastname:string='';
    email:string='';
    pass:string='';
    cpass:string='';
    mobile:number=0;
    
    }