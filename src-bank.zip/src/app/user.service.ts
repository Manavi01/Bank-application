import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './User';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private _URL:string="http://localhost:8891";
  constructor(private http:HttpClient) { }
  save(us: User):Observable<User> {
  
  
  
  return this.http.post<User>(`${this._URL}/saveuser`,us);
  
  }
  login(us:User):Observable<User>
  {
  return this.http.post<User>(`${this._URL}/login`,us);
  }
}
