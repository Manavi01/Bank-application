import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loan',
  templateUrl: './loan.component.html',
  styleUrls: ['./loan.component.css']
})
export class LoanComponent implements OnInit {
amount:number=0;
  constructor() { }

  ngOnInit(): void {
  }
demo(val1:number,val2:number){

this.amount=(val1*val2*0.04)/100;
}
demo1(val1:number,val2:number){

  this.amount=(val1*val2*0.06)/100;
  }
  demo2(val1:number,val2:number){

    this.amount=(val1*val2*0.08)/100;
    }
    demo3(val1:number,val2:number){

      this.amount=(val1*val2*0.09)/100;
      }
  }

